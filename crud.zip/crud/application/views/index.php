<?php
// Load header
$this->load->view('common/header');
?>

   <h3 align="center">Welcome to CRUD</h3>  
   <br />
   <!-- alert message-->
   <div id="alert_message">

   </div>
   <br/>
   <!-- ./ alert message-->

   <div align="right">
    <button type="button" name="add" id="add" class="btn btn-success">Add</button>
   </div>
   <br />
   <div id="image_data">

   </div>
 
<?php
// Load footer
$this->load->view('common/footer');
?>

<?php
// Load imageModal_view
$this->load->view('modals/imageModal');
?>
 
<script src="assets/js/crud.js"></script>

